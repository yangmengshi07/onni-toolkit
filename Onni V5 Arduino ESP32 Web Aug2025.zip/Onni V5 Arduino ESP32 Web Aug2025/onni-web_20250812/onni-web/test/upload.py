import requests
import json

SERVER_URL = "http://1.15.126.128:5000"
DEVICE_ID = "onni002"
PASSWORD = "01189998819991197253"
JSON_FILE = "config.json"  # 本地的 json 文件

# 读取本地 JSON 文件
with open(JSON_FILE, 'r', encoding='utf-8') as f:
    data = json.load(f)

# 上传到服务器
response = requests.post(
    f"{SERVER_URL}/upload/{DEVICE_ID}",
    headers={"X-Auth-Token": PASSWORD},
    json=data
)

if response.ok:
    print("✅ 上传成功:", response.text)
else:
    print("❌ 上传失败:", response.status_code, response.text)
