import requests
import json

SERVER_URL = "http://1.15.126.128:5000"
DEVICE_ID = "onni001"
PASSWORD = "01189998819991197253"
SAVE_AS = "downloaded_config.json"  # 下载后保存的文件名

# 发送下载请求
response = requests.get(
    f"{SERVER_URL}/download/{DEVICE_ID}",
    headers={"X-Auth-Token": PASSWORD}
)

if response.ok:
    data = response.json()
    with open(SAVE_AS, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2)
    print(f"✅ 下载成功，保存为 {SAVE_AS}")
else:
    print("❌ 下载失败:", response.status_code, response.text)
