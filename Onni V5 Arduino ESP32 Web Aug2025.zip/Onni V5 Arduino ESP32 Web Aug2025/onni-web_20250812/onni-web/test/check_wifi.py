import requests
import json
import os

WIFI_JSON_PATH = "../wifi.json"

# 默认配置
default_config = {
    "ESP_IP": "192.168.4.1",  # ESP32 SoftAP IP
    "ssid": None,
    "pwd": None,
    "sta_ip": None  # 动态更新：ESP32 在 STA 模式下的 IP
}


def load_wifi_config():
    """读取或创建 wifi.json 配置文件"""
    if os.path.exists(WIFI_JSON_PATH):
        with open(WIFI_JSON_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    else:
        with open(WIFI_JSON_PATH, "w", encoding="utf-8") as f:
            json.dump(default_config, f, indent=2)
        return default_config.copy()

def save_wifi_config(config):
    with open(WIFI_JSON_PATH, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2, ensure_ascii=False)
        print(f"💾 已写入 sta_ip 到 {WIFI_JSON_PATH}")

def check_sta_ip(config):
    """请求 ESP32 的 STA 模式 IP 并写入本地配置"""
    try:
        url = f"http://{config['ESP_IP']}/sta_ip"
        print(f"📡 正在请求: {url}")
        response = requests.get(url, timeout=3)
        data = response.json()

        sta_ip = data.get("sta_ip")  # ✅ 正确字段名

        if sta_ip and sta_ip != "0.0.0.0":
            print(f"✅ ESP32 已连接热点，STA IP: {sta_ip}")
            config["sta_ip"] = sta_ip
            save_wifi_config(config)
        else:
            print("⚠️ ESP32 尚未连接热点或未分配有效 IP")
    except Exception as e:
        print("❌ 无法连接 ESP32:", e)



if __name__ == "__main__":
    config = load_wifi_config()
    check_sta_ip(config)
