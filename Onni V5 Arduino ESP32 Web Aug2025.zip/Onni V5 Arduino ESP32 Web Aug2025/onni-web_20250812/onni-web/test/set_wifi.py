import json
import requests
import os

WIFI_JSON_PATH = "../wifi.json"


def load_wifi_config():
    """读取 wifi.json 中的配置信息"""
    with open(WIFI_JSON_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def send_wifi_to_esp32(config):
    """将热点 ssid 和密码发送给 ESP32"""
    url = f"http://{config['ESP_IP']}/set_wifi"
    payload = {
        "ssid": config["ssid"], 
        "password": config["pwd"]
    }

    try:
        print(f"📡 正在发送 WiFi 设置到: {url}")
        response = requests.post(url, json=payload, timeout=5)

        if response.ok:
            print("✅ 设置成功，ESP32 将重启并尝试连接热点")
        else:
            print(f"❌ 设置失败，状态码: {response.status_code}，响应: {response.text}")
    except Exception as e:
        print(f"❌ 请求失败: {e}")


if __name__ == "__main__":
    config = load_wifi_config()
    send_wifi_to_esp32(config)
