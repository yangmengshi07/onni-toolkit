import http.server
import socketserver
import webbrowser
import os
import json

PORT = 8000
CONFIG_FILE = "config.json"

# Change working directory to script location
os.chdir(os.path.dirname(os.path.abspath(__file__)))

class CustomHTTPRequestHandler(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_no_cache_headers()
        super().end_headers()

    def send_no_cache_headers(self):
        self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0')
        self.send_header('Pragma', 'no-cache')
        self.send_header('Expires', '0')

    def do_POST(self):
        if self.path == "/save-config":
            content_length = int(self.headers['Content-Length'])
            post_data = self.rfile.read(content_length)

            try:
                config = json.loads(post_data.decode('utf-8'))
                with open(CONFIG_FILE, "w", encoding='utf-8') as f:
                    json.dump(config, f, indent=2, ensure_ascii=False)

                self.send_response(200)
                self.send_header('Content-type', 'text/plain')
                self.end_headers()
                self.wfile.write(b"Config saved successfully")
            except Exception as e:
                self.send_response(500)
                self.send_header('Content-type', 'text/plain')
                self.end_headers()
                self.wfile.write(f"Error saving config: {e}".encode())
        else:
            super().do_POST()


# Start the server
with socketserver.TCPServer(("", PORT), CustomHTTPRequestHandler) as httpd:
    print(f"Server running at: http://localhost:{PORT}/")
    webbrowser.open(f"http://localhost:{PORT}/home.html")
    httpd.serve_forever()
