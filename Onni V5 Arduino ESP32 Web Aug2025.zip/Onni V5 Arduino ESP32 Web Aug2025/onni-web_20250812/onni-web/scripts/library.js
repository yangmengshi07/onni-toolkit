function scaleToFit() {
  const baseWidth = 1440;
  const baseHeight = 1024;
  const winW = window.innerWidth;
  const winH = window.innerHeight;
  const scale = Math.min(winW / baseWidth, winH / baseHeight);
  document.querySelector('.scale-wrapper').style.transform = `scale(${scale})`;
}

window.addEventListener('load', scaleToFit);
window.addEventListener('resize', scaleToFit);

// Submit selected patterns to ESP32
async function submitSelected() {
  const selected = Array.from(document.querySelectorAll('.pattern-checkbox'))
    .filter(cb => cb.checked)
    .map(cb => cb.dataset.id);

  console.log("📤 Selected patterns:", selected);

  try {
    const response = await fetch("http://192.168.4.1/activate_patterns", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ selected })
    });

    if (!response.ok) throw new Error("HTTP error " + response.status);
    const result = await response.json();

    console.log("✅ Activation result from ESP32:", result);

  } catch (err) {
    console.warn("❌ Update failed:", err);
    alert("Update failed. Please check your connection.");
  }
}

