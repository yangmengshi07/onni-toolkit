function scaleToFit() {
  const baseWidth = 1440;
  const baseHeight = 1024;
  const scale = Math.min(window.innerWidth / baseWidth, window.innerHeight / baseHeight);
  document.querySelector('.scale-wrapper').style.transform = `scale(${scale})`;
}

async function loadNameFromConfig() {
  try {
    const response = await fetch("config.json");
    if (!response.ok) throw new Error("Failed to load config.json");

    const config = await response.json();
    console.log("📦 Loaded config.json:", config);

    document.getElementById("my-onni-name").textContent = config.self_id || "My Onni";
    document.getElementById("my-id").textContent = config.self_id || "My Onni";
    document.getElementById("partner-onni-name").textContent = config.partner_id || "Partner Onni";
    document.getElementById("partner-id").textContent = config.partner_id || "Partner Onni";
  } catch (err) {
    console.warn("⚠️ Failed to read config.json:", err);
  }
}

function updateSliderFill(lowerId, upperId) {
  const lower = document.getElementById(lowerId);
  const upper = document.getElementById(upperId);
  const container = lower.parentElement;

  const min = parseFloat(lower.min);
  const max = parseFloat(lower.max);
  const lowerVal = Math.min(lower.value, upper.value);
  const upperVal = Math.max(lower.value, upper.value);

  const startPercent = ((lowerVal - min) / (max - min)) * 100;
  const endPercent = 100 - ((upperVal - min) / (max - min)) * 100;

  container.style.setProperty('--start', `${startPercent}%`);
  container.style.setProperty('--end', `${endPercent}%`);
}

function setupSliders() {
  const pairs = [
    ['breath-lower', 'breath-upper'],
    ['heartbeat-lower', 'heartbeat-upper']
  ];
  for (const [low, high] of pairs) {
    const l = document.getElementById(low);
    const h = document.getElementById(high);
    const handler = () => updateSliderFill(low, high);
    l.addEventListener('input', handler);
    h.addEventListener('input', handler);
    updateSliderFill(low, high);
  }
}

let ESP32_URL = "http://192.168.4.1"; // 默认值备用

async function loadWiFiConfig() {
  try {
    const res = await fetch("../wifi.json");
    if (!res.ok) throw new Error("Failed to load wifi.json");
    const config = await res.json();

    if (config.ESP_IP) {
      ESP32_URL = `http://${config.sta_ip}`;
      console.log("✅ 加载 ESP32 IP:", ESP32_URL);
    } else {
      console.warn("⚠️ wifi.json 中未包含 ESP_IP 字段");
    }
  } catch (err) {
    console.warn("⚠️ 加载 wifi.json 失败:", err);
  }
}

async function fetchConfig() {
  try {
    const res = await fetch(`${ESP32_URL}/info`);
    const config = await res.json();

    document.getElementById("breath-lower").value = config.breathe_lower;
    document.getElementById("breath-upper").value = config.breathe_upper;
    document.getElementById("heartbeat-lower").value = config.heart_lower;
    document.getElementById("heartbeat-upper").value = config.heart_upper;

    updateSliderFill("breath-lower", "breath-upper");
    updateSliderFill("heartbeat-lower", "heartbeat-upper");
  } catch (err) {
    console.warn("⚠️ Failed to fetch config:", err);
  }
}

async function sendConfigUpdate() {
  const config = {
    breathe_lower: parseInt(document.getElementById("breath-lower").value),
    breathe_upper: parseInt(document.getElementById("breath-upper").value),
    heart_lower: parseInt(document.getElementById("heartbeat-lower").value),
    heart_upper: parseInt(document.getElementById("heartbeat-upper").value)
  };

  try {
    const res = await fetch(`${ESP32_URL}/save_config`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(config)
    });

    if (!res.ok) throw new Error("HTTP error " + res.status);
    setTimeout(refreshInfo, 500);
  } catch (err) {
    console.warn("❌ Failed to send config:", err);
    alert("Failed to update configuration. Please check connection.");
  }
}

async function refreshInfo() {
  try {
    const res = await fetch(`${ESP32_URL}/info`);
    const data = await res.json();

    document.getElementById("breath-lower").value = data.breathe_lower;
    document.getElementById("breath-upper").value = data.breathe_upper;
    document.getElementById("heartbeat-lower").value = data.heart_lower;
    document.getElementById("heartbeat-upper").value = data.heart_upper;

    updateSliderFill("breath-lower", "breath-upper");
    updateSliderFill("heartbeat-lower", "heartbeat-upper");
  } catch (err) {
    console.warn("⚠️ Failed to refresh info:", err);
  }
}

window.addEventListener("load", () => {
  scaleToFit();
  loadWiFiConfig();  // 先读取 IP
  setupSliders();
  fetchConfig();
  loadNameFromConfig();

  document.getElementById("update-btn").addEventListener("click", () => {
    sendConfigUpdate();
  });
});

window.addEventListener("resize", scaleToFit);
