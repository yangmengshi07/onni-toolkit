function scaleToFit() {
  const baseWidth = 1440;
  const baseHeight = 1024;
  const winW = window.innerWidth;
  const winH = window.innerHeight;

  const scale = Math.min(winW / baseWidth, winH / baseHeight);
  const wrapper = document.querySelector('.scale-wrapper');
  wrapper.style.transform = `scale(${scale})`;
}

async function loadIDFromConfig() {
    try {
      const response = await fetch("config.json");
      if (!response.ok) throw new Error("Failed to load config");

      const config = await response.json();
      const label = document.getElementById("id-label");

      if (label && config.self_id) {
        label.textContent = config.self_id;
      } else {
        label.textContent = "onni-mock";
      }
    } catch (err) {
      console.error("Failed to parse config.json, using default:", err);
      const label = document.getElementById("id-label");
      if (label) label.textContent = "onni-mock";
    }
  }

window.addEventListener("load", () => {
  scaleToFit();
  setTimeout(loadIDFromConfig, 300);
});

window.addEventListener("resize", scaleToFit);
