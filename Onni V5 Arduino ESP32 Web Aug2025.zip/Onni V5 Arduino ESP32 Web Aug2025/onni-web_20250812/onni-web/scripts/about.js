function scaleToFit() {
  const baseWidth = 1440;
  const baseHeight = 1024;
  const winW = window.innerWidth;
  const winH = window.innerHeight;

  const scale = Math.min(winW / baseWidth, winH / baseHeight);

  const wrapper = document.querySelector('.scale-wrapper');
  wrapper.style.transform = `scale(${scale})`;
}

window.addEventListener('load', scaleToFit);
window.addEventListener('resize', scaleToFit);
