// ===== 全局配置对象 =====
let configData = {
  messages: {
    M1: { input: [], output: [], enabled: false },
    M2: { input: [], output: [], enabled: false },
    M3: { input: [], output: [], enabled: false },
    Tap: { input: [], output: [], enabled: false },
    Poke: { input: [], output: [], enabled: false },
    Wave: { input: [], output: [], enabled: false },
    Hug: { input: [], output: [], enabled: false },
  },
  editing: "M1",
  self_id: "onni-001",
  partner_id: "onni-002",
};

let currentInputSequence = 1;
let currentOutputSequence = 1;
const SERVER_URL = "http://1.15.126.128:5000";
const AUTH_PASSWORD = "01189998819991197253";

// ===== 缩放适配页面尺寸 =====
function scaleToFit() {
  const scale = Math.min(window.innerWidth / 1440, window.innerHeight / 1024);
  document.querySelector(".scale-wrapper").style.transform = `scale(${scale})`;
}
window.addEventListener("load", scaleToFit);
window.addEventListener("resize", scaleToFit);

// ===== 工具函数：绑定多选/单选按钮点击逻辑 =====
function attachOptionHandlers(container) {
  const optionRows = container.querySelectorAll(".option-row");
  optionRows.forEach((row) => {
    const isMulti = row.dataset.multiselect === "true";
    const buttons = row.querySelectorAll(".option-button");
    buttons.forEach((button) => {
      button.addEventListener("click", () => {
        if (isMulti) {
          button.classList.toggle("active");
        } else {
          buttons.forEach((b) => b.classList.remove("active"));
          button.classList.add("active");
        }
      });
    });
  });
}

// ===== 创建新的输入或输出行 =====
function createRow(type, seq) {
  const row = document.createElement("div");
  row.className = `${type}-row input-row`;

  const posButtons = [1, 2, 3, 4, 5, 6]
    .map((n) => `<button class="option-button" data-value="${n}">${n}</button>`)
    .join("");

  row.innerHTML = `
    <div class="cell sequence-cell"><div class="sequence-number">${seq}</div></div>
    <div class="cell"><div class="option-row" data-name="position" data-multiselect="true">${posButtons}</div></div>
    <div class="cell"><div class="option-row" data-name="magnitude">
      <button class="option-button" data-value="light">Light</button>
      <button class="option-button" data-value="heavy">Heavy</button>
    </div></div>
    <div class="cell"><button class="delete-button" onclick="deleteRow(this, '${type}')">×</button></div>
  `;
  return row;
}

// ===== 删除行并重新编号 =====
function deleteRow(button, type) {
  button.closest(".input-row").remove();
  resequence(type);
}

function resequence(type) {
  const container = document.getElementById(`${type}-rows`);
  const numbers = container.querySelectorAll(".sequence-number");
  numbers.forEach((el, i) => (el.textContent = i + 1));
  if (type === "input") currentInputSequence = numbers.length + 1;
  if (type === "output") currentOutputSequence = numbers.length + 1;
}

// ===== 设置行中选中的位置和幅度 =====
function setRowSelections(row, positions, magnitude) {
  row.querySelectorAll('[data-name="position"] .option-button').forEach((btn) => {
    if (positions.includes(btn.dataset.value)) btn.classList.add("active");
  });
  row.querySelectorAll('[data-name="magnitude"] .option-button').forEach((btn) => {
    if (btn.dataset.value === magnitude) btn.classList.add("active");
  });
}

// ===== 加载 message 的配置到页面 =====
function loadConfigurationFor(label) {
  const cfg = configData.messages[label];
  if (!cfg) return;

  currentInputSequence = 1;
  currentOutputSequence = 1;

  const inputRows = document.getElementById("input-rows");
  const outputRows = document.getElementById("output-rows");
  inputRows.innerHTML = "";
  outputRows.innerHTML = "";

  cfg.input.forEach(({ position, magnitude }) => {
    const row = createRow("input", currentInputSequence++);
    setRowSelections(row, position, magnitude);
    inputRows.appendChild(row);
    attachOptionHandlers(row);
  });

  cfg.output.forEach(({ position, magnitude }) => {
    const row = createRow("output", currentOutputSequence++);
    setRowSelections(row, position, magnitude);
    outputRows.appendChild(row);
    attachOptionHandlers(row);
  });
}

// ===== 收集当前页面配置（input/output） =====
function collectConfiguration() {
  const collect = (type) =>
    [...document.querySelectorAll(`#${type}-rows .${type}-row`)].map((row) => {
      const position = [...row.querySelectorAll('[data-name="position"] .option-button.active')].map(
        (btn) => btn.dataset.value
      );
      const magnitude = row.querySelector('[data-name="magnitude"] .option-button.active')?.dataset.value || null;
      return { position, magnitude };
    });
  return { input: collect("input"), output: collect("output") };
}

// ===== 注册 message 按钮点击和右键启用事件 =====
function registerMessageButtons() {
  document.querySelectorAll(".message-button").forEach((btn) => {
    const label = btn.textContent.trim();

    btn.addEventListener("click", (e) => {
      e.preventDefault();
      document.querySelectorAll(".message-button").forEach((b) => b.classList.remove("editing"));
      btn.classList.add("editing");
      configData.editing = label;
      loadConfigurationFor(label);
    });

    btn.addEventListener("contextmenu", (e) => {
      e.preventDefault();
      btn.classList.toggle("enabled");
      configData.messages[label].enabled = btn.classList.contains("enabled");
    });
  });
}

// ===== 保存本地配置并上传到服务器 =====
async function uploadConfigToServer() {
  const label = configData.editing;
  const { input, output } = collectConfiguration();
  configData.messages[label].input = input;
  configData.messages[label].output = output;

  // 同步 enabled 状态
  document.querySelectorAll('.message-button').forEach((btn) => {
    const name = btn.textContent.trim();
    configData.messages[name].enabled = btn.classList.contains("enabled");
  });

  try {
    // ✅ 第一步：保存到本地 config.json
    const localRes = await fetch("/save-config", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(configData),
    });
    if (!localRes.ok) throw new Error(`Local save failed: ${localRes.status}`);
    console.log("💾 Local config saved.");

    // ✅ 第二步：上传到服务器
    const serverRes = await fetch(`${SERVER_URL}/upload/${configData.self_id}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Auth-Token": AUTH_PASSWORD,
      },
      body: JSON.stringify(configData),
    });
    if (!serverRes.ok) throw new Error(`Server upload failed: ${serverRes.status}`);
    console.log("✅ Uploaded to server.");

    // ✅ 第三步：上传给 ESP32（/activate_pattern）
    const espRes = await fetch(`${ESP32_URL}/activate_patterns`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(configData),
    });
    if (!espRes.ok) throw new Error(`ESP32 activate_pattern failed: ${espRes.status}`);
    console.log("🚀 Sent config to ESP32 /activate_patterns");

    alert("配置已保存、本地同步、上传服务器，并发送到 ESP32");
  } catch (err) {
    console.error("❌ Upload failed:", err);
    alert("❌ 上传失败，请检查网络连接和 ESP32 状态");
  }
}



function fetchPartnerConfig() {
  const partnerId = configData.partner_id;

  fetch(`${SERVER_URL}/download/${partnerId}`, {
    method: "GET",
    headers: {
      "X-Auth-Token": AUTH_PASSWORD,
    },
  })
    .then((res) => {
      if (!res.ok) throw new Error(`Fetch failed with status ${res.status}`);
      return res.json();
    })
    .then((fetchedData) => {
      if (!fetchedData.messages) {
        alert("No messages field found in fetched config.");
        return;
      }

      // ✅ 替换整个 configData
      configData = {
        ...fetchedData,
        // 交换 ID
        self_id: fetchedData.partner_id || configData.partner_id,
        partner_id: fetchedData.self_id || configData.self_id,
      };

      const editingId = configData.editing || "M1";

      // ✅ 渲染当前正在编辑的配置
      loadConfigurationFor(editingId);

      // ✅ 更新按钮样式（enabled + editing）
      document.querySelectorAll(".message-button").forEach((btn) => {
        const label = btn.textContent.trim();
        btn.classList.toggle("enabled", configData.messages[label]?.enabled);
        btn.classList.toggle("editing", label === editingId);
      });

      // ✅ 保存本地 config.json
      fetch("/save-config", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(configData),
      })
        .then(() => {
          console.log("💾 Local config updated after fetch.");
          alert(`Fetched and loaded config from "${partnerId}" successfully.`);
        })
        .catch((err) => {
          console.error("❌ Failed to save fetched config:", err);
          alert("Fetched config, but failed to save locally.");
        });
    })
    .catch((err) => {
      console.error("❌ Fetch failed:", err);
      alert("Failed to fetch partner config. Check network or server.");
    });
}

let ESP32_URL = "http://192.168.4.1";  // 默认

async function loadESP32URL() {
  try {
    const res = await fetch("../wifi.json");
    const data = await res.json();
    if (data.ESP_IP) {
      ESP32_URL = `http://${data.sta_ip}`;
      console.log("🌐 ESP32 IP 加载成功:", ESP32_URL);
    } else {
      console.warn("⚠️ wifi.json 中缺少 ESP_IP");
    }
  } catch (err) {
    console.warn("⚠️ 无法读取 wifi.json:", err);
  }
}


// ===== 页面初始化逻辑 =====
function setup() {
  loadESP32URL();  // 初始化时先加载 ESP32 的 IP
  // 初始加载本地 config.json
  fetch("config.json")
    .then((res) => res.json())
    .then((data) => {
      configData = data;

      // === 设置按钮状态 ===
      document.querySelectorAll(".message-button").forEach((btn) => {
        const label = btn.textContent.trim();

        // 设置是否启用
        if (configData.messages[label]?.enabled) {
          btn.classList.add("enabled");
        } else {
          btn.classList.remove("enabled");
        }

        // 设置是否为当前正在编辑
        if (label === configData.editing) {
          btn.classList.add("editing");
        } else {
          btn.classList.remove("editing");
        }
      });

      // === 加载当前编辑的 message ===
      loadConfigurationFor(configData.editing || "M1");

      // 注册按钮事件
      registerMessageButtons();

      // 行内按钮点击逻辑（position & magnitude）
      attachOptionHandlers(document.getElementById("input-rows"));
      attachOptionHandlers(document.getElementById("output-rows"));

      // 行添加按钮
      document.getElementById("add-row-button").addEventListener("click", () => {
        const row = createRow("input", currentInputSequence++);
        document.getElementById("input-rows").appendChild(row);
        attachOptionHandlers(row);
      });

      document.getElementById("add-output-row-button").addEventListener("click", () => {
        const row = createRow("output", currentOutputSequence++);
        document.getElementById("output-rows").appendChild(row);
        attachOptionHandlers(row);
      });

      // 上传、获取按钮
      document.getElementById("uploadButton").addEventListener("click", uploadConfigToServer);
      document.getElementById("fetchButton").addEventListener("click", fetchPartnerConfig);
    })
    .catch((err) => {
      console.error("❌ Failed to load config.json:", err);
    //   alert("无法读取 config.json。请检查本地文件是否存在并格式正确。");
    });
}


window.addEventListener("DOMContentLoaded", setup);
